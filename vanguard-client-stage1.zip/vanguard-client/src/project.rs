//! Project generation (`vanguard init`).

use std::{fs, path::{Path, PathBuf}};

use anyhow::{bail, Context, Result};
use serde_json::json;
use uuid::Uuid;

pub const MAX_NAME_LEN: usize = 64;

/// Names become directory names, so keep them to a conservative portable set.
pub fn validate_project_name(name: &str) -> Result<()> {
    let ok_chars = name.chars().all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_');
    let starts_ok = name.chars().next().is_some_and(|c| c.is_ascii_alphanumeric());
    if name.is_empty() || name.len() > MAX_NAME_LEN || !ok_chars || !starts_ok {
        bail!(
            "invalid project name \"{name}\": use 1-{MAX_NAME_LEN} characters from A-Z a-z 0-9 - _ and start with a letter or digit"
        );
    }
    Ok(())
}

/// Create `<parent>/<name>/` containing a minimal, valid resource pack.
/// Fails if the target directory already exists, so nothing is overwritten.
pub fn init_resource_pack(parent: &Path, name: &str) -> Result<PathBuf> {
    validate_project_name(name)?;
    let root = parent.join(name);
    if root.exists() {
        bail!("{} already exists; refusing to overwrite", root.display());
    }
    fs::create_dir_all(parent).with_context(|| format!("cannot create {}", parent.display()))?;
    fs::create_dir(&root).with_context(|| format!("cannot create {}", root.display()))?;

    let result = write_resource_template(&root, name);
    if result.is_err() {
        // Don't leave a half-written project behind.
        let _ = fs::remove_dir_all(&root);
    }
    result?;
    Ok(root)
}

fn write_resource_template(root: &Path, name: &str) -> Result<()> {
    let manifest = json!({
        "format_version": 2,
        "header": {
            "name": name,
            "description": format!("{name} resource pack"),
            "uuid": Uuid::new_v4().to_string(),
            "version": [1, 0, 0],
            "min_engine_version": [1, 21, 0]
        },
        "modules": [{
            "type": "resources",
            "uuid": Uuid::new_v4().to_string(),
            "version": [1, 0, 0]
        }]
    });
    let text = serde_json::to_string_pretty(&manifest)? + "\n";
    fs::write(root.join("manifest.json"), text).context("cannot write manifest.json")?;

    // Empty directories are not packaged; the dot-file keeps the folder in git.
    let textures = root.join("textures");
    fs::create_dir(&textures).context("cannot create textures/")?;
    fs::write(textures.join(".gitkeep"), "").context("cannot write textures/.gitkeep")?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn name_rules() {
        for ok in ["MyPack", "a", "my-pack_2"] {
            assert!(validate_project_name(ok).is_ok(), "{ok}");
        }
        for bad in ["", "-x", "_x", "has space", "../evil", "a/b", "é", &"x".repeat(65)] {
            assert!(validate_project_name(bad).is_err(), "{bad}");
        }
    }
}
