//! `.mcpack` creation and inspection.
//!
//! Archives are deterministic: entries are sorted, timestamps are fixed to the
//! ZIP epoch (1980-01-01), and permissions are normalised, so packaging the
//! same tree twice yields byte-identical files.

use std::{
    fs::{self, File},
    io::{self, BufReader, BufWriter, Read, Write},
    path::{Path, PathBuf},
};

use anyhow::{anyhow, bail, ensure, Context, Result};
use zip::{write::SimpleFileOptions, CompressionMethod, DateTime, ZipArchive, ZipWriter};

use crate::validation::{self, Report, MAX_MANIFEST_BYTES};

#[derive(Debug)]
pub struct PackageSummary {
    pub output: PathBuf,
    pub entries: usize,
    pub uncompressed_bytes: u64,
    pub archive_bytes: u64,
}

#[derive(Debug)]
pub struct EntryInfo {
    pub name: String,
    pub is_dir: bool,
    pub size: u64,
    pub compressed_size: u64,
}

#[derive(Debug)]
pub struct Inspection {
    pub archive_bytes: u64,
    pub entries: Vec<EntryInfo>,
    /// Archive-level problems plus the manifest diagnostics.
    pub report: Report,
}

/// `<parent of dir>/<dir name>.mcpack`
pub fn default_output_path(dir: &Path) -> Result<PathBuf> {
    let canon = dir.canonicalize().with_context(|| format!("cannot access {}", dir.display()))?;
    let name = canon
        .file_name()
        .and_then(|n| n.to_str())
        .ok_or_else(|| anyhow!("cannot derive an archive name from {}", canon.display()))?;
    let parent = canon.parent().ok_or_else(|| anyhow!("{} has no parent directory", canon.display()))?;
    Ok(parent.join(format!("{name}.mcpack")))
}

/// Files to include as `(archive path with '/', filesystem path)`, sorted.
/// Dot-files and dot-directories are skipped. Symlinks are rejected.
pub fn collect_files(dir: &Path) -> Result<Vec<(String, PathBuf)>> {
    let mut out = Vec::new();
    walk(dir, "", &mut out)?;
    out.sort_by(|a, b| a.0.cmp(&b.0));
    Ok(out)
}

fn walk(cur: &Path, prefix: &str, out: &mut Vec<(String, PathBuf)>) -> Result<()> {
    let mut entries = fs::read_dir(cur)
        .with_context(|| format!("cannot read directory {}", cur.display()))?
        .collect::<io::Result<Vec<_>>>()?;
    entries.sort_by_key(|e| e.file_name());

    for e in entries {
        let os_name = e.file_name();
        let name = os_name
            .to_str()
            .ok_or_else(|| anyhow!("non-UTF-8 file name in {}", cur.display()))?;
        if name.starts_with('.') {
            continue;
        }
        if name.contains('\\') {
            bail!("file name contains a backslash, which ZIP readers treat as a separator: {}", e.path().display());
        }
        let path = e.path();
        let rel = format!("{prefix}{name}");
        let ft = e.file_type()?; // does not follow symlinks
        if ft.is_symlink() {
            bail!("symlinks are not supported inside a pack: {}", path.display());
        } else if ft.is_dir() {
            walk(&path, &format!("{rel}/"), out)?;
        } else if ft.is_file() {
            out.push((rel, path));
        }
    }
    Ok(())
}

/// Validate `dir` and write it to `output` as a `.mcpack`.
/// Refuses to package a pack that has validation errors.
pub fn package(dir: &Path, output: &Path) -> Result<PackageSummary> {
    let report = validation::validate_pack_dir(dir)?;
    ensure!(
        !report.has_errors(),
        "validation failed with {} error(s); run `vanguard validate` for details",
        report.error_count()
    );

    let dir = dir.canonicalize()?;
    let file_name = output
        .file_name()
        .ok_or_else(|| anyhow!("output path has no file name: {}", output.display()))?;
    let out_parent = match output.parent() {
        Some(p) if !p.as_os_str().is_empty() => p,
        _ => Path::new("."),
    };
    let out_parent = out_parent
        .canonicalize()
        .with_context(|| format!("output directory does not exist: {}", out_parent.display()))?;
    ensure!(
        !out_parent.starts_with(&dir),
        "output must be outside the pack directory ({})",
        dir.display()
    );

    let files = collect_files(&dir)?;
    let final_path = out_parent.join(file_name);
    // Write to a temp name first so an interrupted run never leaves a truncated .mcpack.
    let tmp_path = out_parent.join(format!(".{}.tmp", file_name.to_string_lossy()));

    let written = write_archive(&files, &tmp_path);
    let uncompressed_bytes = match written {
        Ok(n) => n,
        Err(e) => {
            let _ = fs::remove_file(&tmp_path);
            return Err(e);
        }
    };
    if let Err(e) = fs::rename(&tmp_path, &final_path) {
        let _ = fs::remove_file(&tmp_path);
        return Err(e).with_context(|| format!("cannot move archive to {}", final_path.display()));
    }
    let archive_bytes = fs::metadata(&final_path)?.len();
    Ok(PackageSummary { output: final_path, entries: files.len(), uncompressed_bytes, archive_bytes })
}

fn write_archive(files: &[(String, PathBuf)], dest: &Path) -> Result<u64> {
    let file = File::create(dest).with_context(|| format!("cannot create {}", dest.display()))?;
    let mut zw = ZipWriter::new(BufWriter::new(file));
    let opts = SimpleFileOptions::default()
        .compression_method(CompressionMethod::Deflated)
        .last_modified_time(DateTime::default())
        .unix_permissions(0o644);

    let mut total = 0u64;
    for (name, path) in files {
        zw.start_file(name.as_str(), opts)?;
        let mut src = File::open(path).with_context(|| format!("cannot open {}", path.display()))?;
        total += io::copy(&mut src, &mut zw).with_context(|| format!("cannot read {}", path.display()))?;
    }
    let mut inner = zw.finish()?;
    inner.flush()?;
    inner.get_ref().sync_all()?;
    Ok(total)
}

/// Open an archive and report its contents, unsafe entry names, and manifest status.
pub fn inspect(archive: &Path) -> Result<Inspection> {
    let file = File::open(archive).with_context(|| format!("cannot open {}", archive.display()))?;
    let archive_bytes = file.metadata()?.len();
    let mut zip = ZipArchive::new(BufReader::new(file))
        .with_context(|| format!("{} is not a readable ZIP archive", archive.display()))?;

    let mut report = Report::default();
    let mut entries = Vec::with_capacity(zip.len());
    for i in 0..zip.len() {
        let f = zip.by_index_raw(i)?;
        if f.enclosed_name().is_none() || f.name().contains('\\') {
            report.error(f.name(), "unsafe entry path (absolute, \"..\" traversal, or backslash); extracting it could write outside the target folder");
        }
        entries.push(EntryInfo {
            name: f.name().to_string(),
            is_dir: f.is_dir(),
            size: f.size(),
            compressed_size: f.compressed_size(),
        });
    }

    if entries.iter().any(|e| e.name == "manifest.json" && !e.is_dir) {
        let mut f = zip.by_name("manifest.json")?;
        if f.size() > MAX_MANIFEST_BYTES {
            report.error("manifest.json", format!("larger than the {MAX_MANIFEST_BYTES}-byte limit"));
        } else {
            let mut bytes = Vec::new();
            f.by_ref().take(MAX_MANIFEST_BYTES + 1).read_to_end(&mut bytes)?;
            match String::from_utf8(bytes) {
                Ok(text) => report.extend(validation::validate_manifest_str(&text)),
                Err(_) => report.error("manifest.json", "not valid UTF-8"),
            }
        }
    } else if let Some(nested) = entries.iter().find(|e| e.name.ends_with("/manifest.json")) {
        report.error(
            "manifest.json",
            format!("not at the archive root (found \"{}\"); Minecraft expects it at the top level", nested.name),
        );
    } else {
        report.error("manifest.json", "missing from archive");
    }

    Ok(Inspection { archive_bytes, entries, report })
}
