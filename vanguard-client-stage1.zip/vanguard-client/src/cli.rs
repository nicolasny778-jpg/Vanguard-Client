//! Command-line parsing and command execution (hand-rolled: four subcommands
//! don't justify a CLI framework dependency yet).

use std::path::PathBuf;

use anyhow::Result;

use crate::{packaging, project, validation};

pub const USAGE: &str = "\
vanguard - Minecraft Bedrock pack tooling (Stage 1: resource packs)

USAGE:
  vanguard init <NAME> [--kind resource] [--dir <PARENT>]   create a new pack project
  vanguard validate <PATH>                                  check a pack directory
  vanguard package <PATH> [-o <FILE>]                       build a .mcpack
  vanguard inspect <ARCHIVE>                                list and check an archive
  vanguard --help | --version

EXIT CODES: 0 ok, 1 validation/runtime failure, 2 usage error";

#[derive(Debug, PartialEq, Eq)]
pub enum Command {
    Help,
    Version,
    Init { name: String, parent: PathBuf },
    Validate { path: PathBuf },
    Package { path: PathBuf, output: Option<PathBuf> },
    Inspect { path: PathBuf },
}

/// Parse arguments (without the program name).
pub fn parse(args: &[String]) -> Result<Command, String> {
    let Some(sub) = args.first() else {
        return Ok(Command::Help);
    };
    let rest = &args[1..];
    match sub.as_str() {
        "-h" | "--help" | "help" => Ok(Command::Help),
        "-V" | "--version" => Ok(Command::Version),
        "init" => parse_init(rest),
        "validate" => Ok(Command::Validate { path: one_path(rest, "validate")? }),
        "inspect" => Ok(Command::Inspect { path: one_path(rest, "inspect")? }),
        "package" => parse_package(rest),
        other => Err(format!("unknown command \"{other}\"")),
    }
}

fn one_path(rest: &[String], cmd: &str) -> Result<PathBuf, String> {
    match rest {
        [p] if !p.starts_with('-') => Ok(PathBuf::from(p)),
        [] => Err(format!("`{cmd}` needs a path")),
        _ => Err(format!("`{cmd}` takes exactly one path")),
    }
}

fn parse_init(rest: &[String]) -> Result<Command, String> {
    let mut name = None;
    let mut parent = PathBuf::from(".");
    let mut i = 0;
    while i < rest.len() {
        match rest[i].as_str() {
            "--kind" => {
                let kind = rest.get(i + 1).ok_or("--kind needs a value")?;
                if kind != "resource" {
                    return Err(format!("kind \"{kind}\" is not implemented yet (Stage 1 supports: resource)"));
                }
                i += 2;
            }
            "--dir" => {
                parent = PathBuf::from(rest.get(i + 1).ok_or("--dir needs a value")?);
                i += 2;
            }
            a if a.starts_with('-') => return Err(format!("unknown option \"{a}\"")),
            a => {
                if name.replace(a.to_string()).is_some() {
                    return Err("`init` takes exactly one NAME".into());
                }
                i += 1;
            }
        }
    }
    Ok(Command::Init { name: name.ok_or("`init` needs a NAME")?, parent })
}

fn parse_package(rest: &[String]) -> Result<Command, String> {
    let mut path = None;
    let mut output = None;
    let mut i = 0;
    while i < rest.len() {
        match rest[i].as_str() {
            "-o" | "--output" => {
                output = Some(PathBuf::from(rest.get(i + 1).ok_or("-o needs a value")?));
                i += 2;
            }
            a if a.starts_with('-') => return Err(format!("unknown option \"{a}\"")),
            a => {
                if path.replace(PathBuf::from(a)).is_some() {
                    return Err("`package` takes exactly one path".into());
                }
                i += 1;
            }
        }
    }
    Ok(Command::Package { path: path.ok_or("`package` needs a path")?, output })
}

fn print_report(report: &validation::Report) {
    for d in &report.diagnostics {
        println!("  {d}");
    }
    println!(
        "{} error(s), {} warning(s)",
        report.error_count(),
        report.warning_count()
    );
}

/// Execute a command. Returns the process exit code.
pub fn run(cmd: Command) -> Result<u8> {
    match cmd {
        Command::Help => {
            println!("{USAGE}");
            Ok(0)
        }
        Command::Version => {
            println!("vanguard {}", env!("CARGO_PKG_VERSION"));
            Ok(0)
        }
        Command::Init { name, parent } => {
            let root = project::init_resource_pack(&parent, &name)?;
            println!("created resource pack at {}", root.display());
            println!("next: vanguard validate {0} && vanguard package {0}", root.display());
            Ok(0)
        }
        Command::Validate { path } => {
            println!("validating {}", path.display());
            let report = validation::validate_pack_dir(&path)?;
            print_report(&report);
            Ok(u8::from(report.has_errors()))
        }
        Command::Package { path, output } => {
            let output = match output {
                Some(o) => o,
                None => packaging::default_output_path(&path)?,
            };
            let s = packaging::package(&path, &output)?;
            println!(
                "wrote {} ({} files, {} bytes -> {} bytes)",
                s.output.display(),
                s.entries,
                s.uncompressed_bytes,
                s.archive_bytes
            );
            Ok(0)
        }
        Command::Inspect { path } => {
            let ins = packaging::inspect(&path)?;
            println!("{} ({} bytes, {} entries)", path.display(), ins.archive_bytes, ins.entries.len());
            for e in &ins.entries {
                println!("  {:>9} -> {:>9}  {}", e.size, e.compressed_size, e.name);
            }
            print_report(&ins.report);
            Ok(u8::from(ins.report.has_errors()))
        }
    }
}
