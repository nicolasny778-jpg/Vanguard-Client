use std::process::ExitCode;

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    match vanguard::cli::parse(&args) {
        Err(msg) => {
            eprintln!("error: {msg}\nrun `vanguard --help` for usage");
            ExitCode::from(2)
        }
        Ok(cmd) => match vanguard::cli::run(cmd) {
            Ok(code) => ExitCode::from(code),
            Err(e) => {
                eprintln!("error: {e:#}");
                ExitCode::from(1)
            }
        },
    }
}
