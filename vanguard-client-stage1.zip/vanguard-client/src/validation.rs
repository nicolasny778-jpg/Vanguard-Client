//! Manifest validation for Bedrock resource packs.
//!
//! What this checks is the documented manifest shape (format_version, header,
//! modules, UUID/version syntax). Passing validation does NOT prove Minecraft
//! will accept the pack; only an in-game import test proves that.

use std::{fmt, fs, path::Path};

use anyhow::{bail, Context, Result};
use serde_json::{Map, Value};

/// Largest manifest we are willing to read (guards against huge/hostile files).
pub const MAX_MANIFEST_BYTES: u64 = 1024 * 1024;

const KNOWN_MODULE_TYPES: &[&str] = &[
    "resources",
    "data",
    "client_data",
    "interface",
    "world_template",
    "script",
];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Severity {
    Error,
    Warning,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Diagnostic {
    pub severity: Severity,
    /// JSON path inside the manifest (e.g. `header.uuid`) or a file name.
    pub path: String,
    pub message: String,
}

impl fmt::Display for Diagnostic {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let sev = match self.severity {
            Severity::Error => "error",
            Severity::Warning => "warning",
        };
        write!(f, "{sev}: {}: {}", self.path, self.message)
    }
}

#[derive(Debug, Default, Clone)]
pub struct Report {
    pub diagnostics: Vec<Diagnostic>,
}

impl Report {
    pub fn error(&mut self, path: impl Into<String>, message: impl Into<String>) {
        self.push(Severity::Error, path, message);
    }

    pub fn warning(&mut self, path: impl Into<String>, message: impl Into<String>) {
        self.push(Severity::Warning, path, message);
    }

    fn push(&mut self, severity: Severity, path: impl Into<String>, message: impl Into<String>) {
        self.diagnostics.push(Diagnostic {
            severity,
            path: path.into(),
            message: message.into(),
        });
    }

    pub fn extend(&mut self, other: Report) {
        self.diagnostics.extend(other.diagnostics);
    }

    pub fn error_count(&self) -> usize {
        self.count(Severity::Error)
    }

    pub fn warning_count(&self) -> usize {
        self.count(Severity::Warning)
    }

    pub fn has_errors(&self) -> bool {
        self.error_count() > 0
    }

    fn count(&self, s: Severity) -> usize {
        self.diagnostics.iter().filter(|d| d.severity == s).count()
    }
}

/// Validate manifest text (as read from `manifest.json`).
pub fn validate_manifest_str(src: &str) -> Report {
    let mut report = Report::default();
    let src = match src.strip_prefix('\u{feff}') {
        Some(rest) => {
            report.warning("$", "file starts with a UTF-8 byte-order mark; remove it");
            rest
        }
        None => src,
    };
    match serde_json::from_str::<Value>(src) {
        Ok(root) => check_manifest(&root, &mut report),
        Err(e) => report.error("$", format!("malformed JSON: {e}")),
    }
    report
}

/// Validate a resource-pack directory: manifest plus basic layout.
pub fn validate_pack_dir(dir: &Path) -> Result<Report> {
    let meta = fs::metadata(dir).with_context(|| format!("cannot access {}", dir.display()))?;
    if !meta.is_dir() {
        bail!("{} is not a directory", dir.display());
    }

    let mut report = Report::default();
    let manifest_path = dir.join("manifest.json");
    match fs::metadata(&manifest_path) {
        Ok(m) if !m.is_file() => report.error("manifest.json", "exists but is not a regular file"),
        Ok(m) if m.len() > MAX_MANIFEST_BYTES => report.error(
            "manifest.json",
            format!("larger than the {MAX_MANIFEST_BYTES}-byte limit"),
        ),
        Ok(_) => {
            let bytes = fs::read(&manifest_path)
                .with_context(|| format!("cannot read {}", manifest_path.display()))?;
            match String::from_utf8(bytes) {
                Ok(text) => report.extend(validate_manifest_str(&text)),
                Err(_) => report.error("manifest.json", "not valid UTF-8"),
            }
        }
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => report.error(
            "manifest.json",
            "not found; it must sit at the root of the pack directory",
        ),
        Err(e) => return Err(e).with_context(|| format!("cannot access {}", manifest_path.display())),
    }

    if !dir.join("pack_icon.png").is_file() {
        report.warning("pack_icon.png", "missing (optional, but recommended)");
    }
    Ok(report)
}

fn check_manifest(root: &Value, r: &mut Report) {
    let Some(obj) = root.as_object() else {
        r.error("$", "top-level value must be a JSON object");
        return;
    };

    match obj.get("format_version") {
        None => r.error("format_version", "missing required field"),
        Some(v) => match v.as_u64() {
            Some(1) | Some(2) => {}
            _ => r.error("format_version", format!("expected 1 or 2, found {v}")),
        },
    }

    // (lowercased uuid, where it was first seen)
    let mut seen: Vec<(String, String)> = Vec::new();

    match obj.get("header") {
        None => r.error("header", "missing required object"),
        Some(Value::Object(h)) => check_header(h, r, &mut seen),
        Some(_) => r.error("header", "must be an object"),
    }

    match obj.get("modules") {
        None => r.error("modules", "missing required array"),
        Some(Value::Array(mods)) => check_modules(mods, r, &mut seen),
        Some(_) => r.error("modules", "must be an array"),
    }

    if let Some(deps) = obj.get("dependencies") {
        check_dependencies(deps, r);
    }
}

fn check_header(h: &Map<String, Value>, r: &mut Report, seen: &mut Vec<(String, String)>) {
    match h.get("name") {
        None => r.error("header.name", "missing required field"),
        Some(Value::String(s)) if s.trim().is_empty() => r.error("header.name", "must not be empty"),
        Some(Value::String(_)) => {}
        Some(_) => r.error("header.name", "must be a string"),
    }
    match h.get("description") {
        None => r.warning("header.description", "missing (recommended)"),
        Some(Value::String(_)) => {}
        Some(_) => r.error("header.description", "must be a string"),
    }
    check_uuid(h.get("uuid"), "header.uuid", r, seen);
    match h.get("version") {
        None => r.error("header.version", "missing required field"),
        Some(v) => check_version(v, "header.version", r),
    }
    if let Some(v) = h.get("min_engine_version") {
        check_version(v, "header.min_engine_version", r);
    }
}

fn check_modules(mods: &[Value], r: &mut Report, seen: &mut Vec<(String, String)>) {
    if mods.is_empty() {
        r.error("modules", "must contain at least one module");
        return;
    }
    let mut types: Vec<String> = Vec::new();
    for (i, m) in mods.iter().enumerate() {
        let base = format!("modules[{i}]");
        let Some(m) = m.as_object() else {
            r.error(&base, "must be an object");
            continue;
        };
        match m.get("type") {
            None => r.error(format!("{base}.type"), "missing required field"),
            Some(Value::String(t)) => {
                if !KNOWN_MODULE_TYPES.contains(&t.as_str()) {
                    r.warning(
                        format!("{base}.type"),
                        format!("unrecognised module type \"{t}\" (known: {})", KNOWN_MODULE_TYPES.join(", ")),
                    );
                }
                types.push(t.clone());
            }
            Some(_) => r.error(format!("{base}.type"), "must be a string"),
        }
        check_uuid(m.get("uuid"), &format!("{base}.uuid"), r, seen);
        match m.get("version") {
            None => r.error(format!("{base}.version"), "missing required field"),
            Some(v) => check_version(v, &format!("{base}.version"), r),
        }
    }
    if !types.iter().any(|t| t == "resources") {
        r.error(
            "modules",
            format!(
                "no module of type \"resources\" (this validator targets resource packs; found: {})",
                if types.is_empty() { "none".to_string() } else { types.join(", ") }
            ),
        );
    }
}

fn check_dependencies(deps: &Value, r: &mut Report) {
    let Some(arr) = deps.as_array() else {
        r.error("dependencies", "must be an array");
        return;
    };
    for (i, d) in arr.iter().enumerate() {
        let base = format!("dependencies[{i}]");
        let Some(d) = d.as_object() else {
            r.error(&base, "must be an object");
            continue;
        };
        match d.get("uuid") {
            Some(v) => {
                check_uuid_syntax(v, &format!("{base}.uuid"), r);
            }
            None if d.contains_key("module_name") => {}
            None => r.error(&base, "needs either \"uuid\" or \"module_name\""),
        }
        match d.get("version") {
            Some(v) => check_version(v, &format!("{base}.version"), r),
            None => r.error(format!("{base}.version"), "missing required field"),
        }
    }
}

fn check_uuid(v: Option<&Value>, path: &str, r: &mut Report, seen: &mut Vec<(String, String)>) {
    let Some(v) = v else {
        r.error(path, "missing required field");
        return;
    };
    if !check_uuid_syntax(v, path, r) {
        return;
    }
    let key = v.as_str().unwrap_or_default().to_ascii_lowercase();
    if let Some((_, first)) = seen.iter().find(|(u, _)| *u == key) {
        r.error(path, format!("duplicate UUID (already used by {first}); every pack/module UUID must be unique"));
    } else {
        seen.push((key, path.to_string()));
    }
}

/// Returns true when `v` is a canonical 8-4-4-4-12 hyphenated UUID string.
fn check_uuid_syntax(v: &Value, path: &str, r: &mut Report) -> bool {
    match v.as_str() {
        Some(s) if s.len() == 36 && uuid::Uuid::parse_str(s).is_ok() => true,
        Some(s) => {
            r.error(path, format!("\"{s}\" is not a valid hyphenated UUID (8-4-4-4-12 hex digits)"));
            false
        }
        None => {
            r.error(path, "must be a string");
            false
        }
    }
}

/// Accepts `[major, minor, patch]` or a `"major.minor.patch"` string
/// (an optional `-prerelease`/`+build` suffix is tolerated).
fn check_version(v: &Value, path: &str, r: &mut Report) {
    const HINT: &str = "expected [major, minor, patch] with non-negative integers, e.g. [1, 0, 0]";
    match v {
        Value::Array(a) => {
            if a.len() != 3 || !a.iter().all(|n| n.as_u64().is_some_and(|n| n <= u32::MAX as u64)) {
                r.error(path, HINT);
            }
        }
        Value::String(s) => {
            let core = s.split(['-', '+']).next().unwrap_or("");
            let parts: Vec<&str> = core.split('.').collect();
            let ok = parts.len() == 3
                && parts.iter().all(|p| !p.is_empty() && p.bytes().all(|b| b.is_ascii_digit()));
            if !ok {
                r.error(path, format!("\"{s}\" is not a MAJOR.MINOR.PATCH string; {HINT}"));
            }
        }
        _ => r.error(path, HINT),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const GOOD: &str = r#"{
      "format_version": 2,
      "header": {"name":"T","description":"d","uuid":"11111111-1111-4111-8111-111111111111","version":[1,0,0],"min_engine_version":[1,21,0]},
      "modules": [{"type":"resources","uuid":"22222222-2222-4222-8222-222222222222","version":[1,0,0]}]
    }"#;

    #[test]
    fn good_manifest_has_no_diagnostics() {
        let r = validate_manifest_str(GOOD);
        assert!(r.diagnostics.is_empty(), "{:?}", r.diagnostics);
    }

    #[test]
    fn version_string_form_is_accepted() {
        let src = GOOD.replace("\"version\":[1,0,0],\"min", "\"version\":\"1.0.0\",\"min");
        assert!(!validate_manifest_str(&src).has_errors());
    }

    #[test]
    fn bom_is_warned_not_fatal() {
        let r = validate_manifest_str(&format!("\u{feff}{GOOD}"));
        assert!(!r.has_errors());
        assert_eq!(r.warning_count(), 1);
    }
}
