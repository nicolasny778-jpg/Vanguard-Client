use std::{fs, io::Write, path::Path};

use tempfile::tempdir;
use vanguard::{packaging, project, validation};
use zip::{write::SimpleFileOptions, ZipWriter};

fn new_pack(parent: &Path, name: &str) -> std::path::PathBuf {
    project::init_resource_pack(parent, name).expect("init")
}

#[test]
fn init_creates_a_pack_that_validates_cleanly_except_icon_warning() {
    let tmp = tempdir().unwrap();
    let root = new_pack(tmp.path(), "MyPack");
    assert!(root.join("manifest.json").is_file());
    let report = validation::validate_pack_dir(&root).unwrap();
    assert_eq!(report.error_count(), 0, "{:?}", report.diagnostics);
    assert_eq!(report.warning_count(), 1); // pack_icon.png
}

#[test]
fn init_generates_distinct_uuids_each_time() {
    let tmp = tempdir().unwrap();
    let a = fs::read_to_string(new_pack(tmp.path(), "A").join("manifest.json")).unwrap();
    let b = fs::read_to_string(new_pack(tmp.path(), "B").join("manifest.json")).unwrap();
    let uuids = |s: &str| -> Vec<String> {
        let v: serde_json::Value = serde_json::from_str(s).unwrap();
        vec![
            v["header"]["uuid"].as_str().unwrap().to_string(),
            v["modules"][0]["uuid"].as_str().unwrap().to_string(),
        ]
    };
    let (ua, ub) = (uuids(&a), uuids(&b));
    assert_ne!(ua[0], ua[1]);
    for x in &ua {
        assert!(!ub.contains(x));
    }
}

#[test]
fn init_refuses_existing_directory_and_bad_names() {
    let tmp = tempdir().unwrap();
    new_pack(tmp.path(), "Dup");
    fs::write(tmp.path().join("Dup").join("keep.txt"), "x").unwrap();
    assert!(project::init_resource_pack(tmp.path(), "Dup").is_err());
    assert!(tmp.path().join("Dup").join("keep.txt").is_file(), "existing files must survive");
    assert!(project::init_resource_pack(tmp.path(), "../escape").is_err());
    assert!(!tmp.path().parent().unwrap().join("escape").exists());
}

#[test]
fn package_then_inspect_roundtrip() {
    let tmp = tempdir().unwrap();
    let root = new_pack(tmp.path(), "RT");
    fs::write(root.join("textures").join("a.txt"), "hello").unwrap();
    fs::write(root.join(".hidden"), "secret").unwrap();

    let out = packaging::default_output_path(&root).unwrap();
    assert_eq!(out.file_name().unwrap(), "RT.mcpack");
    let s = packaging::package(&root, &out).unwrap();
    assert_eq!(s.entries, 2); // manifest.json + textures/a.txt; dot-files skipped

    let ins = packaging::inspect(&out).unwrap();
    let names: Vec<&str> = ins.entries.iter().map(|e| e.name.as_str()).collect();
    assert_eq!(names, ["manifest.json", "textures/a.txt"]);
    assert!(!ins.report.has_errors(), "{:?}", ins.report.diagnostics);
}

#[test]
fn packaging_is_deterministic() {
    let tmp = tempdir().unwrap();
    let root = new_pack(tmp.path(), "Det");
    fs::create_dir_all(root.join("textures/blocks")).unwrap();
    fs::write(root.join("textures/blocks/z.txt"), "z".repeat(5000)).unwrap();
    fs::write(root.join("textures/blocks/a.txt"), "a").unwrap();

    let o1 = tmp.path().join("one.mcpack");
    let o2 = tmp.path().join("two.mcpack");
    packaging::package(&root, &o1).unwrap();
    packaging::package(&root, &o2).unwrap();
    assert_eq!(fs::read(o1).unwrap(), fs::read(o2).unwrap());
}

#[test]
fn package_refuses_invalid_pack_and_leaves_no_output() {
    let tmp = tempdir().unwrap();
    let root = new_pack(tmp.path(), "Bad");
    fs::write(root.join("manifest.json"), "{ nope").unwrap();
    let out = tmp.path().join("Bad.mcpack");
    assert!(packaging::package(&root, &out).is_err());
    assert!(!out.exists());
    let leftovers: Vec<_> = fs::read_dir(tmp.path()).unwrap().map(|e| e.unwrap().file_name()).collect();
    assert!(leftovers.iter().all(|n| !n.to_string_lossy().ends_with(".tmp")), "{leftovers:?}");
}

#[test]
fn package_refuses_output_inside_pack() {
    let tmp = tempdir().unwrap();
    let root = new_pack(tmp.path(), "Inside");
    assert!(packaging::package(&root, &root.join("textures").join("x.mcpack")).is_err());
}

#[cfg(unix)]
#[test]
fn package_rejects_symlinks() {
    let tmp = tempdir().unwrap();
    let root = new_pack(tmp.path(), "Sym");
    std::os::unix::fs::symlink("/etc/hostname", root.join("link")).unwrap();
    let err = packaging::package(&root, &tmp.path().join("Sym.mcpack")).unwrap_err();
    assert!(err.to_string().contains("symlink"), "{err}");
}

#[test]
fn inspect_flags_path_traversal_entries() {
    let tmp = tempdir().unwrap();
    let path = tmp.path().join("evil.mcpack");
    let mut zw = ZipWriter::new(fs::File::create(&path).unwrap());
    let opts = SimpleFileOptions::default();
    zw.start_file("manifest.json", opts).unwrap();
    zw.write_all(b"{}").unwrap();
    zw.start_file("../evil.txt", opts).unwrap();
    zw.write_all(b"x").unwrap();
    zw.start_file("/abs.txt", opts).unwrap();
    zw.write_all(b"x").unwrap();
    zw.finish().unwrap();

    let ins = packaging::inspect(&path).unwrap();
    let unsafe_hits = ins.report.diagnostics.iter().filter(|d| d.message.contains("unsafe entry path")).count();
    assert_eq!(unsafe_hits, 2, "{:?}", ins.report.diagnostics);
    assert!(ins.report.has_errors());
}

#[test]
fn inspect_flags_nested_or_missing_manifest() {
    let tmp = tempdir().unwrap();
    let make = |name: &str, files: &[&str]| {
        let p = tmp.path().join(name);
        let mut zw = ZipWriter::new(fs::File::create(&p).unwrap());
        for f in files {
            zw.start_file(*f, SimpleFileOptions::default()).unwrap();
            zw.write_all(b"{}").unwrap();
        }
        zw.finish().unwrap();
        p
    };
    let nested = packaging::inspect(&make("n.mcpack", &["Pack/manifest.json"])).unwrap();
    assert!(nested.report.diagnostics.iter().any(|d| d.message.contains("not at the archive root")));
    let missing = packaging::inspect(&make("m.mcpack", &["a.txt"])).unwrap();
    assert!(missing.report.diagnostics.iter().any(|d| d.message.contains("missing from archive")));
}

#[test]
fn inspect_rejects_non_zip_input() {
    let tmp = tempdir().unwrap();
    let p = tmp.path().join("fake.mcpack");
    fs::write(&p, "this is not a zip").unwrap();
    assert!(packaging::inspect(&p).is_err());
}
