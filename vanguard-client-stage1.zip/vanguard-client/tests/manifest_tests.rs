use vanguard::validation::{validate_manifest_str, Severity};

const H: &str = "11111111-1111-4111-8111-111111111111";
const M: &str = "22222222-2222-4222-8222-222222222222";

fn manifest(header_uuid: &str, module_uuid: &str) -> String {
    format!(
        r#"{{"format_version":2,
            "header":{{"name":"T","description":"d","uuid":"{header_uuid}","version":[1,0,0]}},
            "modules":[{{"type":"resources","uuid":"{module_uuid}","version":[1,0,0]}}]}}"#
    )
}

fn errors(src: &str) -> Vec<String> {
    validate_manifest_str(src)
        .diagnostics
        .into_iter()
        .filter(|d| d.severity == Severity::Error)
        .map(|d| d.to_string())
        .collect()
}

fn assert_error(src: &str, needle: &str) {
    let e = errors(src);
    assert!(e.iter().any(|m| m.contains(needle)), "expected an error containing {needle:?}, got {e:?}");
}

#[test]
fn valid_manifest_passes() {
    assert!(errors(&manifest(H, M)).is_empty());
}

#[test]
fn malformed_json_is_reported_with_position() {
    assert_error("{ \"format_version\": 2,, }", "malformed JSON");
    assert_error("", "malformed JSON");
}

#[test]
fn non_object_root_is_rejected() {
    assert_error("[1,2,3]", "must be a JSON object");
}

#[test]
fn missing_required_fields_are_named() {
    let e = errors("{}");
    for needle in ["format_version", "header", "modules"] {
        assert!(e.iter().any(|m| m.contains(needle)), "{needle} not reported in {e:?}");
    }
    assert_error(r#"{"format_version":2,"header":{},"modules":[]}"#, "header.name");
    assert_error(r#"{"format_version":2,"header":{},"modules":[]}"#, "header.uuid");
    assert_error(r#"{"format_version":2,"header":{},"modules":[]}"#, "header.version");
    assert_error(r#"{"format_version":2,"header":{},"modules":[]}"#, "at least one module");
}

#[test]
fn bad_format_version() {
    assert_error(&manifest(H, M).replace("\"format_version\":2", "\"format_version\":3"), "expected 1 or 2");
    assert_error(&manifest(H, M).replace("\"format_version\":2", "\"format_version\":\"2\""), "expected 1 or 2");
}

#[test]
fn bad_uuids() {
    assert_error(&manifest("not-a-uuid", M), "header.uuid");
    assert_error(&manifest(H, "2222222222224222822222222222222"), "modules[0].uuid");
    // un-hyphenated (32 hex) form parses in some libraries but is not the manifest format
    assert_error(&manifest("11111111111141118111111111111111", M), "header.uuid");
}

#[test]
fn duplicate_uuid_is_rejected_case_insensitively() {
    assert_error(&manifest(H, H), "duplicate UUID");
    assert_error(&manifest(&H.to_uppercase(), H), "duplicate UUID");
}

#[test]
fn bad_versions() {
    for bad in ["[1,0]", "[1,0,0,0]", "[1,-1,0]", "[1,0,\"x\"]", "[1.5,0,0]", "\"1.0\"", "7", "null"] {
        let src = manifest(H, M).replacen("\"version\":[1,0,0]", &format!("\"version\":{bad}"), 1);
        assert_error(&src, "header.version");
    }
}

#[test]
fn modules_must_include_resources() {
    let src = manifest(H, M).replace("\"resources\"", "\"data\"");
    assert_error(&src, "no module of type \"resources\"");
}

#[test]
fn module_type_must_be_a_string_and_present() {
    assert_error(&manifest(H, M).replace("\"type\":\"resources\",", ""), "modules[0].type");
    assert_error(&manifest(H, M).replace("\"resources\"", "5"), "modules[0].type");
}

#[test]
fn dependencies_are_checked_when_present() {
    let src = manifest(H, M).replacen('}', r#","dependencies":[{"uuid":"zzz","version":[1,0,0]}]}"#, 0);
    // build the manifest with dependencies appended at the root
    let src = src.trim_end().trim_end_matches('}').to_string()
        + r#","dependencies":[{"uuid":"zzz","version":[1,0,0]},{"version":[1,0,0]}]}"#;
    assert_error(&src, "dependencies[0].uuid");
    assert_error(&src, "dependencies[1]");
}

#[test]
fn unknown_module_type_is_only_a_warning() {
    let src = manifest(H, M).replace("\"resources\"", "\"resources\"").replacen(
        "\"modules\":[",
        "\"modules\":[{\"type\":\"mystery\",\"uuid\":\"33333333-3333-4333-8333-333333333333\",\"version\":[1,0,0]},",
        1,
    );
    let r = validate_manifest_str(&src);
    assert!(!r.has_errors(), "{:?}", r.diagnostics);
    assert_eq!(r.warning_count(), 1);
}
