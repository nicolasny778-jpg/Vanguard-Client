//! End-to-end tests that run the compiled `vanguard` binary.

use std::process::{Command, Output};

use tempfile::tempdir;

fn vanguard(args: &[&str], cwd: &std::path::Path) -> Output {
    Command::new(env!("CARGO_BIN_EXE_vanguard"))
        .args(args)
        .current_dir(cwd)
        .output()
        .expect("run vanguard")
}

fn text(o: &Output) -> String {
    format!("{}{}", String::from_utf8_lossy(&o.stdout), String::from_utf8_lossy(&o.stderr))
}

#[test]
fn full_workflow_init_validate_package_inspect() {
    let tmp = tempdir().unwrap();
    let cwd = tmp.path();

    let o = vanguard(&["init", "Demo", "--kind", "resource"], cwd);
    assert_eq!(o.status.code(), Some(0), "{}", text(&o));

    let o = vanguard(&["validate", "Demo"], cwd);
    assert_eq!(o.status.code(), Some(0), "{}", text(&o));

    let o = vanguard(&["package", "Demo"], cwd);
    assert_eq!(o.status.code(), Some(0), "{}", text(&o));
    assert!(cwd.join("Demo.mcpack").is_file());

    let o = vanguard(&["inspect", "Demo.mcpack"], cwd);
    assert_eq!(o.status.code(), Some(0), "{}", text(&o));
    assert!(text(&o).contains("manifest.json"));
}

#[test]
fn validate_exits_1_on_broken_manifest() {
    let tmp = tempdir().unwrap();
    vanguard(&["init", "Broken"], tmp.path());
    std::fs::write(tmp.path().join("Broken/manifest.json"), "{").unwrap();
    let o = vanguard(&["validate", "Broken"], tmp.path());
    assert_eq!(o.status.code(), Some(1));
    assert!(text(&o).contains("malformed JSON"));
}

#[test]
fn usage_errors_exit_2() {
    let tmp = tempdir().unwrap();
    for args in [&["bogus"][..], &["init"], &["init", "x", "--kind", "behavior"], &["package"], &["validate", "a", "b"]] {
        let o = vanguard(args, tmp.path());
        assert_eq!(o.status.code(), Some(2), "{args:?}: {}", text(&o));
    }
}

#[test]
fn help_and_version_work() {
    let tmp = tempdir().unwrap();
    assert_eq!(vanguard(&["--help"], tmp.path()).status.code(), Some(0));
    assert!(text(&vanguard(&["--version"], tmp.path())).starts_with("vanguard 0.1.0"));
}
