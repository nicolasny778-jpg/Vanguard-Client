# Vanguard Forge (Stage 0-1)

Resource-pack CLI for Minecraft Bedrock, built to run in Termux.

    vanguard init <NAME> [--kind resource] [--dir <PARENT>]
    vanguard validate <PATH>
    vanguard package <PATH> [-o <FILE>]
    vanguard inspect <ARCHIVE>

## Build / test (Termux)

    cargo build --release          # binary: target/release/vanguard
    cargo test

## Status (see STATUS below for the verified/unverified split)

VERIFIED (x86_64 Ubuntu sandbox, rustc 1.91.1): builds with 0 warnings; 31 tests pass
(4 unit, 12 manifest, 11 packaging, 4 end-to-end CLI).
NOT VERIFIED: build on Termux/aarch64; import of generated .mcpack into Minecraft;
manifest rules beyond documented shape (e.g. unique-UUID rule is treated as an error
based on documentation/practice, not tested in-game).

## Known limitations
- Resource packs only (`--kind behavior|native` not implemented).
- No pack_icon.png generated (validate warns).
- Dot-files/dirs are not packaged; symlinks are rejected.
- Manifest JSON must be strict JSON (no comments).
- Generated manifest keys are alphabetically ordered (serde_json default).
